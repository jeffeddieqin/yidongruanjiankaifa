const envList = [];
const isMac = false;
module.exports = {
  envList,
  isMac
};
